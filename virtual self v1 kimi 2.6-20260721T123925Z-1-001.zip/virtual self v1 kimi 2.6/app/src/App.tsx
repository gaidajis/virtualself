import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ParticleBackground } from '@/components/ParticleBackground';
import { CenterPortrait } from '@/components/CenterPortrait';
import { TimelineCluster } from '@/components/clusters/TimelineCluster';
import { MusicCluster } from '@/components/clusters/MusicCluster';
import { PlacesCluster } from '@/components/clusters/PlacesCluster';
import { ExpertiseCluster } from '@/components/clusters/ExpertiseCluster';
import { GenealogyCluster } from '@/components/clusters/GenealogyCluster';
import { BottomNavigation } from '@/components/BottomNavigation';
import { DetailPanel } from '@/components/DetailPanel';
import { useVirtualMe } from '@/store/useVirtualMe';
import type { ParisData } from '@/types';
import './App.css';

function App() {
  const { setRawData, activeContext, isTransitioning, setIsTransitioning } = useVirtualMe();
  const [isLoading, setIsLoading] = useState(true);

  // Load data from JSON file
  useEffect(() => {
    const loadData = async () => {
      try {
        const response = await fetch('/paris.json');
        const data: ParisData = await response.json();
        setRawData(data);
        setIsLoading(false);
      } catch (error) {
        console.error('Failed to load paris.json:', error);
        setIsLoading(false);
      }
    };

    loadData();
  }, [setRawData]);

  // Handle transition end
  useEffect(() => {
    if (isTransitioning) {
      const timer = setTimeout(() => {
        setIsTransitioning(false);
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [isTransitioning, setIsTransitioning]);

  // Get context color for status indicator
  const getContextColor = () => {
    switch (activeContext) {
      case 'WORK':
        return 'text-blue-400';
      case 'DATING':
        return 'text-pink-400';
      case 'PRIVATE':
        return 'text-violet-400';
      default:
        return 'text-cyan-400';
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <motion.div
          className="text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <motion.div
            className="w-16 h-16 rounded-full border-2 border-cyan-400/30 border-t-cyan-400 mx-auto mb-4"
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
          />
          <p className="text-cyan-400/70 text-sm tracking-wider uppercase">Initializing VirtualMe...</p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* Particle Background */}
      <ParticleBackground />

      {/* Main Content */}
      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center p-4">
        {/* Header / Status */}
        <motion.div
          className="absolute top-8 left-8"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
        >
          <div className="flex items-center gap-3">
            <div className={`w-2 h-2 rounded-full ${getContextColor().replace('text-', 'bg-')} animate-pulse`} />
            <span className="text-white/40 text-sm tracking-wider uppercase">
              VirtualMe <span className={getContextColor()}>// {activeContext}</span>
            </span>
          </div>
        </motion.div>

        {/* Context transition indicator */}
        <AnimatePresence>
          {isTransitioning && (
            <motion.div
              className="absolute inset-0 z-50 flex items-center justify-center pointer-events-none"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <motion.div
                className={`text-4xl font-bold tracking-widest uppercase ${getContextColor()}`}
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 1.2, opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                {activeContext}
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Central Portrait */}
        <motion.div
          className="relative"
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
        >
          <CenterPortrait />
        </motion.div>

        {/* Orbiting Clusters */}
        <div className="absolute inset-0 pointer-events-none">
          {/* Timeline - Mid Left */}
          <div className="pointer-events-auto">
            <TimelineCluster />
          </div>

          {/* Music/Interests - Top Left */}
          <div className="pointer-events-auto">
            <MusicCluster />
          </div>

          {/* Places - Top Right */}
          <div className="pointer-events-auto">
            <PlacesCluster />
          </div>

          {/* Expertise - Bottom Left */}
          <div className="pointer-events-auto">
            <ExpertiseCluster />
          </div>

          {/* Genealogy - Bottom Right */}
          <div className="pointer-events-auto">
            <GenealogyCluster />
          </div>
        </div>

        {/* Instructions hint */}
        <motion.div
          className="absolute top-1/2 right-8 -translate-y-1/2 text-right hidden lg:block"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 1.2 }}
        >
          <p className="text-white/30 text-xs tracking-wider uppercase mb-1">Click clusters</p>
          <p className="text-white/20 text-xs">to explore data</p>
        </motion.div>

        <motion.div
          className="absolute top-1/2 left-8 -translate-y-1/2 hidden lg:block"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 1.2 }}
        >
          <p className="text-white/30 text-xs tracking-wider uppercase mb-1">Select context</p>
          <p className="text-white/20 text-xs">to filter view</p>
        </motion.div>
      </div>

      {/* Bottom Navigation */}
      <BottomNavigation />

      {/* Detail Panel */}
      <DetailPanel />

      {/* Ambient glow effects */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl" />
      </div>
    </div>
  );
}

export default App;
