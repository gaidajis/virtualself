import { motion } from 'framer-motion';
import { useVirtualMe } from '@/store/useVirtualMe';
import { getClusterOpacity } from '@/lib/dataFilter';
import type { ClusterType } from '@/types';

interface BaseClusterProps {
  type: ClusterType;
  position: { x: string; y: string };
  label: string;
  icon: React.ReactNode;
  children?: React.ReactNode;
  glowColor?: string;
}

export function BaseCluster({
  type,
  position,
  label,
  icon,
  children,
  glowColor = 'rgba(100, 200, 255, 0.5)',
}: BaseClusterProps) {
  const { activeCluster, setActiveCluster, activeContext } = useVirtualMe();
  const isActive = activeCluster === type;
  const opacity = getClusterOpacity(type || '', activeContext);

  const handleClick = () => {
    setActiveCluster(isActive ? null : type);
  };

  return (
    <motion.div
      className="absolute cursor-pointer"
      style={{
        left: position.x,
        top: position.y,
        transform: 'translate(-50%, -50%)',
        opacity,
      }}
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity }}
      transition={{ duration: 0.5, delay: 0.2 }}
      whileHover={{ scale: 1.1 }}
      onClick={handleClick}
    >
      {/* Glow effect */}
      <motion.div
        className="absolute inset-0 rounded-full blur-xl"
        style={{ backgroundColor: glowColor }}
        animate={{
          scale: isActive ? [1, 1.3, 1] : [1, 1.1, 1],
          opacity: isActive ? 0.6 : 0.3,
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />

      {/* Main cluster node */}
      <motion.div
        className={`relative w-20 h-20 rounded-full flex items-center justify-center backdrop-blur-md border border-white/20 ${
          isActive ? 'bg-white/20' : 'bg-slate-900/60'
        }`}
        animate={{
          boxShadow: isActive
            ? `0 0 40px ${glowColor}, inset 0 0 20px ${glowColor}`
            : `0 0 20px ${glowColor}`,
        }}
        transition={{ duration: 0.3 }}
      >
        {icon}
      </motion.div>

      {/* Label */}
      <motion.div
        className="absolute -bottom-8 left-1/2 -translate-x-1/2 whitespace-nowrap"
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
      >
        <span className="text-sm font-medium text-white/80 tracking-wider uppercase">
          {label}
        </span>
      </motion.div>

      {/* Connection line to center */}
      <svg
        className="absolute top-1/2 left-1/2 pointer-events-none"
        style={{
          width: '200px',
          height: '2px',
          transformOrigin: '0 50%',
          transform: `rotate(${Math.atan2(
            50 - parseInt(position.y),
            50 - parseInt(position.x)
          )}rad)`,
        }}
      >
        <motion.line
          x1="40"
          y1="1"
          x2="200"
          y2="1"
          stroke={glowColor}
          strokeWidth="1"
          strokeDasharray="4 4"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 1, delay: 0.5 }}
        />
      </svg>

      {/* Children (visual decorations) */}
      {children}
    </motion.div>
  );
}
