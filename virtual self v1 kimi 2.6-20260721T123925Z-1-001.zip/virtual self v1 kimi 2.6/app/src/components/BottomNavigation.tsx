import { motion } from 'framer-motion';
import { useVirtualMe } from '@/store/useVirtualMe';
import type { ContextType } from '@/types';
import { Globe, Heart, Briefcase, Lock, ZoomIn } from 'lucide-react';

const contexts: { id: ContextType; label: string; icon: React.ElementType; color: string }[] = [
  { id: 'PUBLIC', label: 'PUBLIC', icon: Globe, color: 'from-cyan-500 to-blue-500' },
  { id: 'DATING', label: 'DATING', icon: Heart, color: 'from-pink-500 to-rose-500' },
  { id: 'WORK', label: 'WORK', icon: Briefcase, color: 'from-blue-500 to-indigo-500' },
  { id: 'PRIVATE', label: 'PRIVATE', icon: Lock, color: 'from-violet-500 to-purple-500' },
];

export function BottomNavigation() {
  const { activeContext, setActiveContext, setIsTransitioning } = useVirtualMe();

  const handleContextChange = (context: ContextType) => {
    if (context === activeContext) return;
    setIsTransitioning(true);
    setActiveContext(context);
    setTimeout(() => setIsTransitioning(false), 500);
  };

  return (
    <motion.div
      className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50"
      initial={{ y: 100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5, delay: 0.8 }}
    >
      <div className="flex items-center gap-2 p-2 rounded-2xl bg-slate-900/80 backdrop-blur-xl border border-white/10 shadow-2xl">
        {contexts.map((context) => {
          const Icon = context.icon;
          const isActive = activeContext === context.id;

          return (
            <motion.button
              key={context.id}
              onClick={() => handleContextChange(context.id)}
              className={`relative px-4 py-2.5 rounded-xl font-medium text-sm tracking-wider transition-all duration-300 ${
                isActive
                  ? 'text-white'
                  : 'text-white/50 hover:text-white/80'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              {/* Active background */}
              {isActive && (
                <motion.div
                  className={`absolute inset-0 rounded-xl bg-gradient-to-r ${context.color}`}
                  layoutId="activeContext"
                  transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                  style={{ opacity: 0.9 }}
                />
              )}

              {/* Glow effect */}
              {isActive && (
                <motion.div
                  className={`absolute inset-0 rounded-xl bg-gradient-to-r ${context.color} blur-lg`}
                  animate={{ opacity: [0.5, 0.8, 0.5] }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
              )}

              {/* Content */}
              <span className="relative z-10 flex items-center gap-2">
                <Icon className="w-4 h-4" />
                {context.label}
              </span>
            </motion.button>
          );
        })}

        {/* Divider */}
        <div className="w-px h-6 bg-white/20 mx-1" />

        {/* Zoom button */}
        <motion.button
          className="relative px-3 py-2.5 rounded-xl text-white/50 hover:text-white/80 transition-colors"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <ZoomIn className="w-4 h-4" />
        </motion.button>
      </div>

      {/* Context indicator text */}
      <motion.div
        className="absolute -top-8 left-1/2 -translate-x-1/2 whitespace-nowrap"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
      >
        <span className="text-xs text-white/40 tracking-widest uppercase">
          Select Context
        </span>
      </motion.div>
    </motion.div>
  );
}
