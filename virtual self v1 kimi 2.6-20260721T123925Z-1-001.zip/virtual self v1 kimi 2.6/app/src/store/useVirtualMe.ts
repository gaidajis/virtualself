import { create } from 'zustand';
import type { ContextType, ClusterType, ParisData } from '@/types';

interface VirtualMeState {
  // Current context
  activeContext: ContextType;
  setActiveContext: (context: ContextType) => void;
  
  // Active cluster for detail panel
  activeCluster: ClusterType;
  setActiveCluster: (cluster: ClusterType) => void;
  
  // Data
  rawData: ParisData | null;
  setRawData: (data: ParisData) => void;
  
  // UI State
  isPanelOpen: boolean;
  setIsPanelOpen: (open: boolean) => void;
  
  // Animation state
  isTransitioning: boolean;
  setIsTransitioning: (transitioning: boolean) => void;
}

export const useVirtualMe = create<VirtualMeState>((set) => ({
  activeContext: 'PUBLIC',
  setActiveContext: (context) => set({ activeContext: context, isTransitioning: true }),
  
  activeCluster: null,
  setActiveCluster: (cluster) => set({ activeCluster: cluster, isPanelOpen: cluster !== null }),
  
  rawData: null,
  setRawData: (data) => set({ rawData: data }),
  
  isPanelOpen: false,
  setIsPanelOpen: (open) => set({ isPanelOpen: open }),
  
  isTransitioning: false,
  setIsTransitioning: (transitioning) => set({ isTransitioning: transitioning }),
}));
